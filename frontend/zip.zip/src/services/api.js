import axios from "axios";

const API_URL = "http://127.0.0.1:8000";

export const api = axios.create({
  baseURL: API_URL,
  timeout: 10000,
});

// =========================
// DASHBOARD
// =========================

export function getDashboard() {
  return api.get("/scanner/dashboard");
}

// =========================
// DISCOVERED WALLETS
// =========================

export function getDiscoveredWallets() {
  return api.get("/discovered-wallets");
}

export function getWallet(walletAddress) {
  return api.get(`/discovered-wallets/${walletAddress}`);
}

// =========================
// WALLETS
// =========================

export function getWalletRanking() {
  return api.get("/trades/ranking");
}

export function getWalletProfile(walletAddress) {
  return api.get(`/trades/profile/${walletAddress}`);
}

export function getWalletTrades(walletAddress) {
  return api.get(`/trades/wallet/${walletAddress}`);
}

export function getWalletNetwork(walletAddress) {
  return api.get(`/trades/network/${walletAddress}`);
}

// =========================
// DISCOVERY
// =========================

export function runDiscovery(
  walletAddress,
  maxTokens = 3,
  maxWalletsPerToken = 3
) {
  return api.post(
    `/trades/discovery/full/${walletAddress}`,
    null,
    {
      params: {
        max_tokens: maxTokens,
        max_wallets_per_token: maxWalletsPerToken,
      },
    }
  );
} 