from backend.app.services.smart_score_engine import calculate_smart_score
from backend.app.services.dna_engine import calculate_wallet_dna
from backend.app.services.conviction_engine import calculate_wallet_conviction
from backend.app.services.holding_engine import calculate_wallet_holding
from backend.app.services.prediction_engine import calculate_wallet_prediction
from backend.app.services.influence_engine import calculate_wallet_influence


def build_wallet_profile(db, wallet_address: str):
    smart = calculate_smart_score(db, wallet_address)

    dna = calculate_wallet_dna(db, wallet_address)

    conviction = calculate_wallet_conviction(db, wallet_address)

    holding = calculate_wallet_holding(db, wallet_address)

    prediction = calculate_wallet_prediction(db, wallet_address)

    influence = calculate_wallet_influence(db, wallet_address)

    return {
        "wallet": wallet_address,
        "smart_score": smart["smart_score"],
        "version": smart["version"],
        "classification": dna["classification"],
        "traits": dna["traits"],
        "performance": smart["components"]["performance_score"],
        "timing": smart["components"]["timing_score"],
        "leadership": smart["components"]["leadership_score"],
        "conviction": conviction["conviction_score"],
        "holding": holding["holding_score"],
        "prediction": prediction["prediction_score"],
        "influence": influence["influence_score"],
        "risk": smart["components"]["risk_score"],
    } 